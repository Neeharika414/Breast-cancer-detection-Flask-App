# Breast cancer detection Flask App

This app classifies breast cancer tumors as malignant or benign.

You can see the code of the model in this [Jupyter notebook](https://nbviewer.jupyter.org/github/vincent1bt/Healthy-notebooks/blob/master/breastCancer.ipynb).

App avaiable [in this web page](https://breast-cancer-flask.herokuapp.com/).